window.onload = function(){
    alert("11111");

    // document.getElementById("button").click(function(){
    //     document.getElementById("button").style.display = "none";
    // });
    
    var btn = document.getElementById("button");
    btn.onclick = function(){
        document.getElementById("button").style.display = "none";
    }
    //typeof 操作符检测数据类型
    var data = function(){};
    console.log(typeof(data));//返回Object
    var data1 = undefined;
    console.log(typeof(data1));//返回underfined
    var data2 = 1;
    console.log(typeof(data2));//返回number
    var data3 = "1";
    console.log(typeof(data3));//返回String

    //null类型只有一个值 表示一个空对象指针
    var car = null;//将来想用来保存对象的变量都要初始化为null
    console.log("car=",typeof(car)); //返回Object

    //null和underfined的相等性测试
    console.log(null == undefined);//返回true

    //可以用null值来检验一个变量是否被一个对象引用
    if(car != null){//返回true表示person没有被初始化，false表示已经保存了一个对象的引用
        console.log("1");//已经被对象引用，可以进行操作
        car = new Object();
        car.name = "mike";
    }else{
        console.log("2");//未被对象引用，进行对象操作报错
        //car = new Object(); 引用之后不会报错
        car.name = "mike";//报错
    }
    console.log(car.name);//mike
}
